module Main where

import Sudoku

main :: IO ()
main = putStrLn "Hello Sudoku"
