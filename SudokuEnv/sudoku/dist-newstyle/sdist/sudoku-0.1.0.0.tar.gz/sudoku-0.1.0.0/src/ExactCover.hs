module ExactCover where

import Data.Matrix

-- type CoverMatrix a = Matrix a

-- SIZE = (m*n) * (m*n)
-- BOX_SIZE = m * n;
-- EMPTY_CELL = EMPTY;
-- // 4 constraints : cell, line, column, boxes
-- CONSTRAINTS = 4;
--
-- MIN_VALUE = 1;
-- MAX_VALUE = SIZE;
-- // Starting index for cover matrix
-- COVER_START_INDEX = 1;

-- createCoverMatrix :: Board -> CoverMatrix Int
