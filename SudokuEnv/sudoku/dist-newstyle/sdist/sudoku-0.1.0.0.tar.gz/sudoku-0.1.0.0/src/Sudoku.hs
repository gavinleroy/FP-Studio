module Sudoku (parseBoard, printBoard, solve) where

import Data.List     (intersperse, transpose)
import Control.Monad (replicateM)

data Cell
  = Fixed Int
  | Choices [Int]
instance Show Cell where
  show (Fixed i)    = show i
  show (Choices _)  = "."
instance Eq Cell where
  (Fixed x) == (Fixed y) = x == y
  _ == _                 = False

type Size     = (Int, Int)
type Row a    = [a]
type Matrix a = [Row a]
type Board    = (Matrix Cell, Size)

solved3x2 :: Board
solved3x2 = ([[Fixed 1, Fixed 2, Fixed 3, Fixed 4, Fixed 5, Fixed 6],
             [Fixed 4, Fixed 5, Fixed 6, Fixed 1, Fixed 2, Fixed 3],

             [Fixed 2, Fixed 3, Fixed 4, Fixed 5, Fixed 6, Fixed 1],
             [Fixed 5, Fixed 6, Fixed 1, Fixed 2, Fixed 3, Fixed 4],

             [Fixed 3, Fixed 4, Fixed 5, Fixed 6, Fixed 1, Fixed 2],
             [Fixed 6, Fixed 1, Fixed 2, Fixed 3, Fixed 4, Fixed 5]], 
             (3, 2))

incorrect3x2 :: Board
incorrect3x2 = ([[Fixed 1, Fixed 2, Fixed 3, Fixed 4, Fixed 5, Fixed 1],
             [Fixed 4, Fixed 5, Fixed 6, Fixed 1, Fixed 2, Fixed 3],

             [Fixed 2, Fixed 3, Fixed 4, Fixed 5, Fixed 6, Fixed 1],
             [Fixed 5, Fixed 6, Fixed 1, Fixed 2, Fixed 3, Fixed 4],

             [Fixed 3, Fixed 4, Fixed 5, Fixed 6, Fixed 1, Fixed 2],
             [Fixed 6, Fixed 1, Fixed 2, Fixed 3, Fixed 4, Fixed 5]], 
             (3, 2))

-- Utility Functions --

isUnique :: Eq a => [a] -> Bool
isUnique []     = True
isUnique (x:xs) = not (x `elem` xs) && isUnique xs

chunksOf :: Int -> [a] -> [[a]]
chunksOf _ [] =  []
chunksOf n xs =  take n xs : chunksOf n (drop n xs)

rows :: Matrix a -> [Row a]
rows = id

cols :: Matrix a -> [Row a]
cols = transpose

blocks :: Size -> Matrix a -> [Row a]
blocks (m, n) = join . map cols . chunk
  where
     chunk      = chunksOf n . map chunkrows
     chunkrows  = chunksOf m
     join       = map concat . concat

isValid :: Board -> Bool
isValid (b, mxn) 
  = all isUnique (rows b) 
  && all isUnique (cols b)
  && all isUnique (blocks mxn b)

-- Functions for Solving the Sudoku --
















{- Brute Force Algorithm
 - -}
solveBoard :: Board -> Board
solveBoard = undefined

{- Knuth's Algorithm X for Exact Cover
 - 1. Convert the Sudoku Board to a Cover Matrix
 -  1.a Create Blank Cover Matrix
 - 2. Create the Quadruple Chained Linked List
 - 3. Solve
 - 4. Convert back to a Sudoku Board
 - -}
solveBoardAlgoX :: Board -> Board
solveBoardAlgoX = undefined







solve :: Board -> Board
-- solve = solveBoard
solve = solveBoardAlgoX

ssolved3x2 :: String
ssolved3x2 = unlines ["3 2"
                     ,"1 2 3 4 5 6"
                     ,"4 5 6 1 2 3"
                     ,"2 3 4 5 6 1"
                     ,"5 6 1 2 3 4"
                     ,"3 4 5 6 1 2"
                     ,"6 1 2 3 4 5"]

-- Parsing a Board --

parseCell :: Int -> String -> Cell
parseCell mx "." = Choices [1..mx]
parseCell mx cs =  Fixed $ read cs

parseCellRow :: Int -> String -> Row Cell
parseCellRow mxn = map (parseCell mxn) . words

parseBoard :: String -> Board
parseBoard cs = (brd, (m, n))
  where
    brd = map (parseCellRow (m * n)) $ tail $ lines cs
    (m:n:[]) = map read $ words $ head $ lines cs :: [Int]

-- Printing a Board --
  
row2string :: Int -> [Cell] -> String
row2string m [] = "\n"
row2string m cs 
  = (unwords $ map show $ take m cs) 
  ++ "   " 
  ++ (row2string m $ drop m cs)

concatins :: Int -> [String] -> String
concatins n [] = []
concatins n ss 
  = (concat $ take n ss) 
  ++ "\n" 
  ++ (concatins n $ drop n ss)

printBoard :: Board -> IO ()
printBoard (board, (m, n)) 
  = putStrLn 
  $ unlines 
  [show m ++ "x" ++ show n
  , (concatins n $ map (row2string m) board)]

